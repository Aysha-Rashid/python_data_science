def printString(string: str):
    return print(string)
