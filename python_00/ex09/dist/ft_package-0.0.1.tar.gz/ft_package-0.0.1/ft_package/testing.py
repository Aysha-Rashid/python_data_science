def countStringLen(string: str):
    return len(string)
